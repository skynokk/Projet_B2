<?php

namespace App\Form;

use App\Entity\Personne;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;


class InscriptionType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('nom', null, array('attr' => array('placeholder' => 'Nom',),'label' => false,))
            ->add('prenom', null, array('attr' => array('placeholder' => 'Prenom',),'label' => false,))
            ->add('mail', null, array('attr' => array('placeholder' => 'Mail',),'label' => false,))
            ->add('sexe', null, array('attr' => array('placeholder' => 'Sexe',),'label' => false,))
            ->add('login', null, array('attr' => array('placeholder' => 'Login',),'label' => false,))
            ->add('password', PasswordType::class, array('attr' => array('placeholder' => 'Mot de Passe',),'label' => false,))
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Personne::class,
        ]);
    }
}
