<?php

namespace App\Controller;

use Doctrine\Common\Persistence\ObjectManager;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\Personne;
use App\Form\InscriptionType;
use App\Entity\BienImmobilier;
use App\Entity\TypeBien;

//CRUD
use App\CRUD\BienImmobilierCRUD;

class ImmoController extends AbstractController
{
 
    /**
     * @Route("/", name="immo")
     * 
     */
    public function index()
    {
  
        $repo = $this->getDoctrine()->getRepository(BienImmobilier::class);
        //$cataloge = $BICRUD->findAll();
        $cataloge = $repo->findAll();
        $rep = $this->getDoctrine()->getRepository(TypeBien::class);
        $typez = $rep->findAll(0);

        return $this->render('immo/index.html.twig', [
            'controller_name' => 'ImmoController',
            'cataloges' => $cataloge,
            'typezs' => $typez,      
        ]);
    }

    /**
     * @Route("/achat",name="achat")
     * 
     */
    public function acheter(){
        $repo = $this->getDoctrine()->getRepository(BienImmobilier::class);
        $cataloge = $repo->findAll();
        return $this->render('immo/acheter.html.twig',[
            'cataloges' => $cataloge,
        ]);
    }

    /**
     * @Route("/catalogue/{id}",name="show")
     */
    public function show($id){
        $repo = $this->getDoctrine()->getRepository(BienImmobilier::class);
        $nom = $repo->find($id);
        
        return $this->render('immo/seul.html.twig',[
            'noms'=> $nom,
        ]);
    }

     /**
     * @Route("/Login",name="Login")
     */
    public function Login(){
        return $this->render('immo/Login.html.twig');
    }

     /**
     * @Route("/profil",name="profil")
     */
    public function profil(){
        return $this->render('immo/profil.html.twig');
    }

     /**
     * @Route("/Inscription",name="Inscription")
     */
    public function Inscription(Request $request, ObjectManager $manager)
    {
        $personne = new Personne();
        $form = $this->createForm(InscriptionType::class, $personne);

        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid()) {
            $manager->persist($personne);
            $manager->flush();
            return $this->render('immo/inscriptionreussi.html.twig');
        }

        return $this->render('immo/Inscription.html.twig', [
            'form' => $form->createView()
        ]);
        
    }




    public function findAllBienImmobilier(): array
    {
        $conn = $this->getEntityManager()->getConnection();

        $sql = '
            SELECT i.id, i.nb_pieces, i.description, t.libelle 
            FROM BienImmobilier i, TypeBien t
            WHERE i.type_bien_id = 
            ORDER BY p.price ASC
            ';
        $stmt = $conn->prepare($sql);
        $stmt->execute(['price' => $price]);

        // returns an array of arrays (i.e. a raw data set)
        return $stmt->fetchAll();
    }

      /**
     * @Route("/Inscriptionreussi",name="inscriptionreussi")
     */
    public function inscriptionreussi(){
        return $this->render('immo/inscriptionreussi.html.twig');
    }



}
